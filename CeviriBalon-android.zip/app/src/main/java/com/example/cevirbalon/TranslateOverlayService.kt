package com.example.cevirbalon

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslateOverlayService : AccessibilityService() {

    private lateinit var wm: WindowManager

    private var bubble: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var panel: View? = null
    private var panelText: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible = false

    private var listPanel: View? = null
    private var listContainer: LinearLayout? = null
    private var listParams: WindowManager.LayoutParams? = null
    private var listVisible = false

    private var translator: Translator? = null
    private var translatorPair: Pair<String, String>? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pendingRunnable: Runnable? = null

    private lateinit var prefs: android.content.SharedPreferences
    private var prefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private val overlayType =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        startPersistentNotification()
        createBubble()
        createPanel()
        createListPanel()
        applyBubbleVisibility()

        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "bubble_on") applyBubbleVisibility()
        }
        prefsListener = listener
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    // Ana uygulamadaki "balonu göster/gizle" anahtarına göre balonu ve panelleri anında gizler/gösterir.
    private fun applyBubbleVisibility() {
        val on = prefs.getBoolean("bubble_on", true)
        bubble?.visibility = if (on) View.VISIBLE else View.GONE
        if (!on) {
            panelVisible = false
            listVisible = false
            panel?.visibility = View.GONE
            listPanel?.visibility = View.GONE
        }
    }

    private fun startPersistentNotification() {
        val channelId = "ceviri_balon_servis"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Çeviri Balonu", NotificationManager.IMPORTANCE_MIN
            )
            channel.description = "Çeviri balonu arka planda aktif kalır."
            channel.setShowBadge(false)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("Çeviri Balonu aktif")
            .setContentText("Yazarken anında çeviri hazır.")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .setPriority(Notification.PRIORITY_MIN)
            .build()
        try {
            startForeground(1, notif)
        } catch (_: Exception) { }
    }

    // ---------- Yuvarlak açma/kapama butonu ----------
    // Kısa dokunuş: yazarken otomatik çeviri panelini aç/kapat.
    // Uzun basma: ekrandaki mesajları listele.
    private fun createBubble() {
        val b = TextView(this).apply {
            text = "⇄"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(Pal.ACCENT)
            background = d
            elevation = dp(4).toFloat()
        }
        val size = dp(52)
        val params = WindowManager.LayoutParams(
            size, size, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = dp(16)
        params.y = dp(160)

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var downTime = 0L
        val longPressMs = 450L

        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    wm.updateViewLayout(b, params)
                    if (panelVisible) repositionPanel()
                    if (listVisible) repositionListPanel()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        val held = System.currentTimeMillis() - downTime
                        if (held >= longPressMs) toggleListPanel() else togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
        wm.addView(b, params)
        bubble = b
        bubbleParams = params
    }

    // ---------- Yazarken otomatik çeviri paneli ----------
    private fun createPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(16))
            val d = GradientDrawable()
            d.cornerRadius = dp(18).toFloat()
            d.setColor(Pal.CARD)
            background = d
            elevation = dp(6).toFloat()
        }
        val head = TextView(this).apply {
            text = "Çeviri  ·  kısa dokun"
            textSize = 12f
            setTextColor(Pal.MUTED)
            setPadding(0, 0, 0, dp(8))
        }
        val body = TextView(this).apply {
            text = "Yazmaya başladığında burada görünecek…"
            textSize = 15f
            setTextColor(Pal.TEXT)
            setLineSpacing(4f, 1f)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        val copyBtn = smallButton("Kopyala", Pal.ACCENT, Color.WHITE) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("ceviri", body.text.toString()))
            Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }
        row.addView(copyBtn)
        outer.addView(head); outer.addView(body); outer.addView(row)

        val params = WindowManager.LayoutParams(
            dp(240), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        outer.visibility = View.GONE
        wm.addView(outer, params)
        panel = outer
        panelText = body
        panelParams = params
    }

    private fun repositionPanel() {
        val bp = bubbleParams ?: return
        val pp = panelParams ?: return
        pp.x = bp.x
        pp.y = bp.y + dp(60)
        panel?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, pp) }
    }

    private fun togglePanel() {
        if (listVisible) toggleListPanel()
        panelVisible = !panelVisible
        panel?.visibility = if (panelVisible) View.VISIBLE else View.GONE
        if (panelVisible) repositionPanel()
    }

    // ---------- Ekrandaki mesajları listeleyen panel ----------
    private fun createListPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            val d = GradientDrawable()
            d.cornerRadius = dp(18).toFloat()
            d.setColor(Pal.CARD)
            background = d
            elevation = dp(6).toFloat()
        }
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val head = TextView(this).apply {
            text = "Ekrandaki mesajlar"
            textSize = 13f
            setTextColor(Pal.TEXT)
        }
        val headLp = LinearLayout.LayoutParams(0, -2, 1f)
        headRow.addView(head, headLp)
        val refreshBtn = smallButton("Yenile", Pal.ACCENT_SOFT, Pal.TEXT) { scanAndFillList() }
        headRow.addView(refreshBtn)
        outer.addView(headRow)

        val sub = TextView(this).apply {
            text = "Her satırın yanındaki ikona dokun, o mesaj çevrilsin."
            textSize = 11f
            setTextColor(Pal.MUTED)
            setPadding(0, dp(4), 0, dp(10))
        }
        outer.addView(sub)

        val scroll = ScrollView(this)
        scroll.layoutParams = LinearLayout.LayoutParams(-1, dp(360))
        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        scroll.addView(container)
        outer.addView(scroll)

        val params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        outer.visibility = View.GONE
        wm.addView(outer, params)
        listPanel = outer
        listContainer = container
        listParams = params
    }

    private fun repositionListPanel() {
        val bp = bubbleParams ?: return
        val pp = listParams ?: return
        pp.x = bp.x
        pp.y = bp.y + dp(60)
        listPanel?.let { if (it.isAttachedToWindow) wm.updateViewLayout(it, pp) }
    }

    private fun toggleListPanel() {
        if (panelVisible) togglePanel()
        listVisible = !listVisible
        listPanel?.visibility = if (listVisible) View.VISIBLE else View.GONE
        if (listVisible) {
            repositionListPanel()
            scanAndFillList()
        }
    }

    // Ekrandaki aktif pencereyi tarayıp görünen metinleri toplar.
    private fun scanAndFillList() {
        val container = listContainer ?: return
        container.removeAllViews()
        val root = rootInActiveWindow
        if (root == null) {
            container.addView(infoRow("Ekran okunamadı, tekrar dene."))
            return
        }
        val texts = LinkedHashSet<String>()
        collectTexts(root, texts)
        if (texts.isEmpty()) {
            container.addView(infoRow("Görünen yazı bulunamadı."))
            return
        }
        texts.take(30).forEach { t -> container.addView(buildMessageRow(t)) }
    }

    private fun collectTexts(node: AccessibilityNodeInfo, out: MutableSet<String>) {
        if (out.size >= 60) return
        val t = node.text?.toString()?.trim()
        if (!t.isNullOrEmpty() && t.length in 1..300) out.add(t)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectTexts(child, out)
            child.recycle()
        }
    }

    private fun infoRow(msg: String): View = TextView(this).apply {
        text = msg
        textSize = 13f
        setTextColor(Pal.MUTED)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun buildMessageRow(original: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val d = GradientDrawable()
            d.cornerRadius = dp(12).toFloat()
            d.setColor(Pal.BACKGROUND)
            background = d
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val orig = TextView(this).apply {
            text = original
            textSize = 13f
            setTextColor(Pal.TEXT)
            maxLines = 3
        }
        val origLp = LinearLayout.LayoutParams(0, -2, 1f)
        topRow.addView(orig, origLp)

        val result = TextView(this).apply {
            textSize = 13f
            setTextColor(Pal.ACCENT)
            setPadding(0, dp(6), 0, 0)
            visibility = View.GONE
        }

        val transBtn = TextView(this).apply {
            text = "⇄"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val d = GradientDrawable(); d.shape = GradientDrawable.OVAL; d.setColor(Pal.ACCENT)
            background = d
        }
        val btnSize = dp(30)
        val btnLp = LinearLayout.LayoutParams(btnSize, btnSize)
        btnLp.marginStart = dp(8)
        transBtn.setOnClickListener {
            result.text = "Çevriliyor…"
            result.visibility = View.VISIBLE
            ensureTranslator {
                doTranslate(original) { r -> result.text = r }
            }
        }
        topRow.addView(transBtn, btnLp)

        card.addView(topRow)
        card.addView(result)

        card.setOnLongClickListener {
            if (result.visibility == View.VISIBLE) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ceviri", result.text.toString()))
                Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
            }
            true
        }
        return card
    }

    private fun smallButton(text: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 12f
        b.setTextColor(fg)
        val d = GradientDrawable(); d.cornerRadius = dp(14).toFloat(); d.setColor(bg)
        b.background = d
        b.setPadding(dp(16), dp(6), dp(16), dp(6))
        b.minHeight = 0
        b.minimumHeight = 0
        b.setOnClickListener { onClick() }
        return b
    }

    // ---------- Metin izleme ve çeviri (yazarken otomatik) ----------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!panelVisible) return
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return
        val text = e.text?.joinToString(" ")?.trim().orEmpty()
        if (text.isEmpty()) return

        pendingRunnable?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            ensureTranslator {
                doTranslate(text) { result -> panelText?.text = result }
            }
        }
        pendingRunnable = r
        handler.postDelayed(r, 350)
    }

    private fun ensureTranslator(onReady: () -> Unit) {
        val prefs = getSharedPreferences("cevir", Context.MODE_PRIVATE)
        val src = prefs.getString("src", "tr") ?: "tr"
        val tgt = prefs.getString("tgt", "en") ?: "en"

        if (translator != null && translatorPair == Pair(src, tgt)) {
            onReady(); return
        }
        translator?.close()
        val opts = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.fromLanguageTag(src) ?: TranslateLanguage.TURKISH)
            .setTargetLanguage(TranslateLanguage.fromLanguageTag(tgt) ?: TranslateLanguage.ENGLISH)
            .build()
        translator = Translation.getClient(opts)
        translatorPair = Pair(src, tgt)
        panelText?.text = "Dil paketi hazırlanıyor…"
        translator?.downloadModelIfNeeded()
            ?.addOnSuccessListener { onReady() }
            ?.addOnFailureListener { panelText?.text = "İndirme başarısız, internet gerekli (ilk sefer)." }
    }

    private fun doTranslate(text: String, onResult: (String) -> Unit) {
        translator?.translate(text)
            ?.addOnSuccessListener { result -> onResult(result) }
            ?.addOnFailureListener { onResult("Çeviri yapılamadı.") }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        prefsListener?.let { prefs.unregisterOnSharedPreferenceChangeListener(it) }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel?.let { runCatching { wm.removeView(it) } }
        listPanel?.let { runCatching { wm.removeView(it) } }
        translator?.close()
    }
}
